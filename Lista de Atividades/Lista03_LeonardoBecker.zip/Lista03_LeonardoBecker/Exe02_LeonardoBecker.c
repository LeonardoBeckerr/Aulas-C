#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL,"Portuguese");
int num1,num2;
	printf("Digite o m�s e o dia do seu nascimento e veja seu signo \n");
	scanf("%d %d",&num1,&num2);
	
switch(num1)
	{
	case 1: 
		if (num2 >= 1 && num2 <= 19)
			printf("Voc� � do signo de Capric�rnio");
		else if (num2 >= 20 && num2 <= 31)
			printf("Voc� � do signo de Aqu�rio");
		else
			printf("Dia Invalido");
		break;

	case 2:
		if (num2 >= 1 && num2 <= 18)
			printf("Voc� � do signo de Aqu�rio");
		else if (num2 >= 19 && num2 <= 29)
			printf("Voc� � do signo de Peixes");
		else
			printf("Dia Invalido");
		break;

	case 3:
		if (num2 >= 1 && num2 <= 20)
			printf("Voc� � do signo de Peixes");
		else if (num2 >= 21 && num2 <= 31)
			printf("Voc� � do signo de �ries");
		else
			printf("Dia Invalido");
		break;

	case 4:
		if (num2 >= 1 && num2 <= 19)
			printf("Voc� � do signo de �ries");
		else if (num2 >= 20 && num2 <= 30)
			printf("Voc� � do signo de Touro");
		else
			printf("Dia Invalido");
		break;

	case 5:
		if (num2 >= 1 && num2 <= 20)
			printf("Voc� � do signo de Touro");
		else if (num2 >= 21 && num2 <= 31)
			printf("Voc� � do signo de G�meos");
		else
			printf("Dia Invalido");
		break;

	case 6:
		if (num2 >= 1 && num2 <= 21)
			printf("Voc� � do signo de G�meos");
		else if (num2 >= 22 && num2 <= 30)
			printf("Voc� � do signo de C�ncer");
		else
			printf("Dia Invalido");
		break;

	case 7:
		if (num2 >= 1 && num2 <= 22)
			printf("Voc� � do signo de C�ncer");
		else if (num2 >= 23 && num2 <= 31)
			printf("Voc� � do signo de Le�o");
		else
			printf("Dia Invalido");
		break;

	case 8:
		if (num2 >= 1 && num2 <= 22)
			printf("Voc� � do signo de Le�o");
		else if (num2 >= 23 && num2 <= 31)
			printf("Voc� � do signo de Virgem");
		else
			printf("Dia Invalido");
		break;

	case 9:
		if (num2 >= 1 && num2 <= 22)
			printf("Voc� � do signo de Virgem");
		else if (num2 >= 23 && num2 <= 30)
			printf("Voc� � do signo de Libra");
		else
			printf("Dia Invalido");
		break;

	case 10:
		if (num2 >= 1 && num2 <= 22)
			printf("Voc� � do signo de Libra");
		else if (num2 >= 23 && num2 <= 31)
			printf("Voc� � do signo de Escorpi�o");
		else
			printf("Dia Invalido");
		break;

	case 11:
		if (num2 >= 1 && num2 <= 21)
			printf("Voc� � do signo de Escorpi�o");
		else if (num2 >= 22 && num2 <= 30)
			printf("Voc� � do signo de Sagit�rio");
		else
			printf("Dia Invalido");
		break;

	case 12:
		if (num2 >= 1 && num2 <= 21)
			printf("Voc� � do signo de Sagit�rio");
		else if (num2 >= 22 && num2 <= 31)
			printf("Voc� � do signo de Capric�rnio");
		else
			printf("Dia Invalido");
		break;
		
	default: 
		printf("M�s Invalido");
	}
}
