#include <stdio.h>
#include <string.h>
#include <locale.h>

int sub_rotina(int x){

	if (x>0){
		printf("O numero %d � positivo",x);
		return 1;
	}
		
	else if (x==0){
		printf("O numero %d � neutro",x);
		return 0;
	}
		
	else{
		printf("O numero %d � negativo",x);
		return 0;
	}	

}

