#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL,"Portuguese");
	int numero;
	printf("Digite sua idade: \n");
	scanf("%d", &numero);
	if (numero >= 0 && numero <= 11.)
		printf("Voc� � crian�a");
	else if (numero >= 12 && numero <= 18)
		printf("Voc� � adolescente");
	else if (numero >= 19 && numero <= 24)
		printf("Voc� � jovem");
	else if (numero >= 25 && numero <= 59)
		printf("Voc� � adulto");
	else if (numero >= 60)
		printf("Voc� � idoso");	
	else 
		printf("Numero Invalido");
}